# Pergamon Regen — final pre-merge

Regenerated from master-v5. Preview, retest the validator, then merge.

## Regen order (your sequence)
1. Replace docs-site/docs/ contents + mkdocs.yml with these.
2. Preview:  cd docs-site && mkdocs serve
3. Retest validator:
     unzip -o archi-tape-0001-example.zip
     python3 validate_archi.py archimedes-tape-0001 archi-profile-v0.1.json
     # expect: TAPE VALID: 1 bag(s), all checks pass.
4. Merge to main.
5. (after merge, on main) edit the homepage "Archimedes Series" paragraphs — ARCHI
   (format) alongside the Archimedes tape (physical artifact); public + expert review.

## What changed this pass
- DeepSeek worked example: fully source-verified; training_logs row dropped; ledger
  resolution = resolved (no invented review).
- "status vocabulary" -> "markedness vocabulary" (page title, nav label, prose).
- Voice pass: two loose "exactly"s cut (kept the two precise ones); "keeps federation
  honest" -> mechanistic "binds the claim to its sources"; typos (collaboration,
  arguments) fixed.
- The prune (Completeness/Process-Openness grades gone; ARCHI-Ledger-Resolution) — as
  already shipped in the code artifacts, now consistent in docs.

## Still open (post-merge, on main)
- Homepage Archimedes Series prose (#1).
- Host archi-tape-0001-example.zip as a GitHub Release asset; link from example page.
- NOTE: the mkdocs.yml here matches your working docs-site (nested "Archimedes Profile"
  nav group). If you prefer the flat single-sidebar version from the earlier launch
  package, say so — this pass preserved YOUR current structure rather than overwriting it.
